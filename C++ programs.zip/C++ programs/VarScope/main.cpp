#include <iostream>

using namespace std;

int num = 10;

int main()
{
    int num = 21;

    cout << num << endl;
    cout << :: num << endl;

    cout << :: num * 10 << endl;
    cout << :: num / 10 << endl;

    cout << :: num++ << endl;
    cout << :: num << endl;
    cout << num + 29 << endl;

    return 0;
}
