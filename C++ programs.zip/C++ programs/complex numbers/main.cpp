#include <iostream>
using namespace std;
class complex
{
  int i,r;
  public:
  void read()
  {
    cout<<"\n enter real part:";
    cin>>r;
    cout<<"\n enter imaginary part:";
    cin>>i;
  }
  void display()
  {
     cout<<"\n="<<r<<"+"<<i<<"i";
  }
    complex operator+(complex a2)
    {
       complex a;
       a.r=r+a2.r;
       a.i=i+a2.i;
       return a;
    }
       complex operator-(complex a2)
    {
       complex a;
       a.r=r+a2.r;
       a.i=i+a2.i;
       return a;
    }
    complex operator*(complex a2)
    {
      complex a;
      a.r=(r*a2.r)-(i*a2.i);
      a.i=(r*a2.i)+(i*a2.r);
    }
    complex operator/(complex a2)
    {
      complex a;
      a.r=((r*a2.r)+(i*a2.i))/((a2.r*a2.r)+(a2.i*a2.i));
      a.i=((i*a2.r)-(r*a2.i))/((a2.r*a2.r)+(a2.i*a2.i));
      }
};
   int main()
   {
   complex c1,c2,c3;
   c1.read();
   c1.display();
   c2.read();
   c2.display();
   cout<<"\n addition:"<<endl;
   c3=c1+c2;
   c3.display();
   cout<<"\n subtraction:"<<endl;
   c3=c1-c2;
   c3.display();
   cout<<"\n multiplication:"<<endl;
   c3=c1*c2;
   c3.display();
   cout<<"\n division:"<<endl;
   c3=c1/c2;
   c3.display();
   return 0;
   }
