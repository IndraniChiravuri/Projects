#include <iostream>
using namespace std;
class line
{
 public:
     inline int largest(int a,int b,int c)
     {
        int big;
        big= (a>b)?(a>c?a:c):(b>c?b:c);
        return big;
    }
};
int main()
{
   int x,y,z;
   line l;
   cout<<"enter 3 values";
   cin>>x>>y>>z;
   cout<<l.largest(x,y,z);
}
