#include <iostream>

using namespace std;

class Time {

    private:
        int Hours;
        int Mins;
        int Secs;

    public:
        Time() {
            Hours = 0;
            Mins = 0;
            Secs = 0;
        }
        Time(int H, int M, int S) {
            Hours = H;
            Mins = M;
            Secs = S;
        }
        void AddTime(Time T1,Time T2) {
            Secs = T1.Secs + T2.Secs;
            Mins = Secs / 60;
            Secs %= 60;
            Mins += T1.Mins + T2.Mins;
            Hours = Mins / 60;
            Mins %= 60;
            Hours = T1.Hours + T2.Hours;
        }
        void Display() {
            cout << Hours << ":" << Mins << ":" << Secs<< endl;
        }
};

int main() {
    Time T1(9,10,40);
    Time T2(11,40,60);
    Time T3;
    T3.AddTime(T1,T2);

    cout << "Time T1 is:\t";
    T1.Display();
    cout << "Time T2 is:\t";
    T2.Display();
    cout << "Time T1 + time T2 is:\t";
    T3.Display();

    return 0;
}
