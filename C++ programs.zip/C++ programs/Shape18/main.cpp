#include <iostream>

using namespace std;

class Shape {
    public :
        double Length;
        double Breadth;

        void GetData() {
            cout << "Enter Length:\t";
            cin >> Length;
            cout << "Enter breadth:\t";
            cin >> Breadth;
        }

        virtual void DisplayArea() = 0;
};

class Triangle : public Shape {
    public :
        void DisplayArea() {
            cout << "Area of triangle is:\t" << (Length * Breadth) / 2 << endl;
        }
};

class Rectangle : public Shape {
    public :
    void DisplayArea() {
        cout << "Area of rectangle is:\t" << (Length * Breadth) << endl;
    }
};
int main() {
    Shape *Bptr;

    Triangle t;
    Bptr = &t;
    Bptr -> GetData();
    Bptr -> DisplayArea();

    Rectangle r;
    Bptr = &r;
    Bptr -> GetData();
    Bptr -> DisplayArea();

    return 0;
}
