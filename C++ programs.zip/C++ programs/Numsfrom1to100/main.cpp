#include <iostream>

using namespace std;

int main()
{
    int i = 1;
    cout << "Natural numbers:" << endl;
    while(i < 101)
    {
        cout << i << " ";
        i += 1;
    }

    return 0;
}
