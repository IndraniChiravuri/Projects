#include <iostream>

using namespace std;

class Person {
    public :
        char Name[20];
        int Age;
        void GetPrDetails() {
            cout << "Enter name:\t";
            cin >> Name;
            cout << "Enter age:\t";
            cin >> Age;
        }
        void DisplayPrDetails() {
            cout << "\tName is:\t" << Name << endl;
            cout << "\tAge is:\t" << Age << endl;
        }
};

class Student : public Person {
    public :
        int Regdno;
        char Branch[10];
        void GetStDetails() {
            GetPrDetails();
            cout << "Enter regdno:\t" << Regdno;
            cin >> Regdno;
            cout << "Enter branch:\t" << Branch;
            cin >> Branch;
        }
        void DisplayStDetails() {
            DisplayPrDetails();
            cout << "\tRegdno is:\t" << Regdno << endl;
            cout << "\tBranch is:\t" << Branch << endl;
        }
};

class Marks : public Student {
    private :
        float sub1;
        float sub2;
        float total;
    public :
        void GetMarks() {
            GetStDetails();
            cout << "Enter sub1 marks:\t";
            cin >> sub1;
            cout << "Enter sub2 marks:\t";
            cin >> sub2;
        }
        void TotalMarks() {
            total = sub1 + sub2;
        }
        void DisplayMarks() {
            cout << "Details of student are:" << endl;
            DisplayStDetails();
            cout << "\tSub1 marks are:\t" << sub1 << endl;
            cout << "\tSub2 marks are:\t" << sub2 << endl;
            cout << "\tTotal marks are:\t" << total << endl;
        }
};
int main() {
    Marks M;
    M.GetMarks();
    M.TotalMarks();
    M.DisplayMarks();

    return 0;
}
