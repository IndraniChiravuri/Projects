#include <iostream>

using namespace std;

int main()
{
    int marks;
    cout << "Enter subject marks:" << endl;
    cin >> marks;
    char Grade;

    if(marks >= 85 && marks <= 100)
        Grade = 'O';
    else if(marks >= 60 && marks < 85)
        Grade = 'A';
    else if(marks >= 45 && marks < 60)
        Grade = 'B';
    else if(marks >= 35 && marks < 45)
        Grade = 'C';
    else if(marks < 35)
        Grade = 'F';

    cout << "Your subject grade is " << Grade << endl;

    return 0;
}
