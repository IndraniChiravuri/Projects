#include <iostream>
#define max 20
using namespace std;
class stack
{
int top;
int arr[max];
public:
stack ()
{
 int i;
 top=-1;
 for (i=0;i<max;i++)
 arr[i]=0;
 }
 void push(int ele)
 {
 if(top==max-1)
 cout<<"the stack is full"<<endl;
 else
 arr[++top]=ele;
 }
 int pop()
 {
 int temp;
 if (top==-1)

 cout<<"the stack ic empty"<<endl;
 else
 temp=arr[top--];
 return temp;
 }
 void display()
 {
 int i;
 if(top==-1)
 cout<<"the stack is empty"<<endl;
 else
 {
 for(i=top;i>=0;i--)
 cout<<arr[i]<<"";
  }
 }
};
int main()
{
int choice,ele;
stack s1;
do
{
 cout<<"1.push\n 2.pop\n 3.display\n 4.exit\n";
 cout<<"enter element:"<<endl;
 cin>>choice;
 switch(choice)
 {
 case 1:
 cout<<"insert element into stack";
 cin>>ele;
 s1.push(ele);
 break;
 case 2:
 ele=s1.pop();
 cout<<"remove the element from the stack is :"<<ele<<endl;
 break;
 case 3:
 cout<<"the elements present in the stack :"<<endl;
 s1.display();
 cout<<endl;
 break;
 case4:
 cout<<"end of the execution of stack"<<endl;
 break;
 }
 }
 while(choice!=4);
 return 0;
 }

