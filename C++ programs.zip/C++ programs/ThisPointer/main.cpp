#include <iostream>

using namespace std;

class PersonDetails {
    private :
        int age;
        char name[20];
    public :

        void GetPersonDetails() {
            cout << "Enter name " << endl;
            cin >> name;
            cout << "Enter age " << endl;
            cin >> age;
        }

        PersonDetails FindElder(PersonDetails p1) {
            if (p1.age > this->age)
                return p1;
            else
                return *this;
        }

        void Display() {
            cout << "Elder person name is " << name << " with age " << age << endl;
        }

};

int main()
{
    PersonDetails p1,p2,p3;

    cout << "Enter the 1st person details" << endl;
    p1.GetPersonDetails();
    cout << "Enter the 2nd person details" << endl;
    p2.GetPersonDetails();

    p3 = p2.FindElder(p1);
    p3.Display();

    return 0;
}
