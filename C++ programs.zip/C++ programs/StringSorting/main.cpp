#include <iostream>

using namespace std;

void Sorting(char[] ,int );

int main()
{
    char str[20];
    int n;
    cout << "Enter the size of string: " << endl;
    cin >> n;

    cout << "Enter the characters of string:" << endl;
    for(int i = 0;i < n ;i ++)
    cin >> str[i];
    Sorting(str , n);
    return 0;
}

void Sorting(char str[20],int n) {
    int i,j;
    for(i = 0;i < n; i ++)
    {
        for(j = i + 1;j < n; j ++)
        {
            if(str[i] > str[j])
            {
                char temp;
                temp = str[i];
                str[i] = str[j];
                str[j] = temp;
            }
        }
    }
    for(int i = 0; i < n; i ++)
        cout << str[i] << " ";
}
