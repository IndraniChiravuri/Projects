#include <iostream>

using namespace std;

class Student {
    public :
        int Regdno;
        char Branch[10];

        void GetStData() {
            cout << "Enter regdno:\t";
            cin >> Regdno;
            cout << "Enter branch:\t";
            cin >> Branch;
        }

        void DisplayStData() {
            cout << "\tRegdno is:\t" << Regdno << endl;
            cout << "\tBranch is:\t" << Branch << endl;
        }
};

class InternalMarks : virtual public Student {
    public :
        int Sub1;
        int Sub2;

        void GetInternals()  {
            cout << "Enter sub1 internal marks:\t";
            cin >> Sub1;
            cout << "Enter sub2 internal marks:\t";
            cin >> Sub2;
        }

        int TotalInternals() {
            return (Sub1 + Sub2);
        }

        void DisplayInternals() {
            cout << "Marks obtained in internals are:\n";
            cout << "\tSub1 internal marks are:\t" << Sub1 << endl;
            cout << "\tSub2 internal marks are:\t" << Sub2 << endl;
            cout << "\tTotal internal marks are:\t" << TotalInternals() << endl;
        }
};

class ExternalMarks : virtual public Student {
    public :
        int Esub1;
        int Esub2;

        void GetExternals() {
            cout << "Enter sub1 external marks:\t";
            cin >> Esub1;
            cout << "Enter sub2 external marks:\t";
            cin >> Esub2;
        }

        int TotalExternals() {
            return (Esub1 + Esub2);
        }


        void DisplayExternals() {
            cout << "Marks obtained in externals are:\n";
            cout << "\tSub1 external marks are:\t" << Esub1 << endl;
            cout << "\tSub2 external marks are:\t" << Esub2 << endl;
            cout << "\tTotal external marks are:\t" << TotalExternals() << endl;
        }
};

class Semester : public InternalMarks, public ExternalMarks {
    public :
        int TotalMarks() {
            return (TotalInternals() + TotalExternals());
        }

        void GetDetails() {
            GetStData();
            GetInternals();
            GetExternals();
        }

        void DisplayDetails() {
            cout << "Details of the student are:" << endl;
            DisplayStData();
            DisplayInternals();
            DisplayExternals();
            cout << "Total semester result is:\t" << TotalMarks() << endl;
        }
};

int main(){
    Semester S;
    S.GetDetails();
    S.DisplayDetails();
    return 0;
}
