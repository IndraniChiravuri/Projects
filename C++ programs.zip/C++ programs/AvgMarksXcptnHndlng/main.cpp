#include <iostream>

using namespace std;

class OUTOFRANGE { };

float CalAverage(int m1, int m2, int m3, int m4) {
    if ((m1 <= 100 && m1 <= 100) && (m2 >= 0 && m2 <= 100) && (m3 >= 0 && m3 <= 100) && (m4 >= 0 && m4 <= 100)) {
       float m1 = (float)m1;
       return((m1 + m2 + m3 + m4) / 4);
    } else {
        throw OUTOFRANGE();
    }
}


int main() {
    int sub1,sub2,sub3,sub4;

    cout << "Enter marks of 4 subjects:\t";
    cin >> sub1 >> sub2 >> sub3 >> sub4;

    try {
         cout << "Average is:\t" << CalAverage(sub1,sub2,sub3,sub4);
    }
    catch(OUTOFRANGE obj) {
        cout << "Invalid marks!!(marks should be 0 <= marks <= 100)" << endl;
    }

    return 0;
}

