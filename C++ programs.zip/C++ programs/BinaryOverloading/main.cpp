#include <iostream>

using namespace std;

class Complex {
    int real;
    int imag;
    public :
        Complex() {
            real = 0;
            imag = 0;
        }
        Complex(int r,int i) {
            real = r;
            imag = i;
        }
        Complex operator +(Complex C) {
            Complex temp;
            temp.real = real + C.real;
            temp.imag = imag + C.imag;
            return temp;
        }
        void Display() {
            cout << real << '+' << imag << "i" << endl;
        }
};

int main() {

    Complex C1(9,2);
    Complex C2(21,8);
    Complex C3;
    cout << "First Complex number is:\t";
    C1.Display();
    cout << "Second Complex number is:\t";
    C2.Display();
    C3 = C1 + C2;
    cout << "Addition of two complex numbers is:\t";
    C3.Display();

    return 0;
}
