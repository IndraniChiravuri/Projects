#include <iostream>

using namespace std;

int main()
{

    cout << "Natural numbers:" << endl;
    for(int i = 1; i < 101 ; i ++)
        cout << i << " ";
    return 0;
}
