#include <iostream>

using namespace std;

int main()
{
    int num1,num2,sum;
    cout <<"Enter the value of num1:" << endl;
    cin >> num1;

    cout <<"Enter the value of num2:" << endl;
    cin >> num2 ;

    sum = num1 + num2 ;
    cout << "The sum of given numbers is:" << sum << endl;

    return 0;
}
