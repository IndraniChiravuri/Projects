
#include <iostream>

using namespace std;

class Myclass
{
    int num;
    static int cnt;
    public:

        void setdata(int n)
        {
            num = n;
            cnt ++;
        }
    static int showcount()
    {
        return cnt;
    }
};

int Myclass :: cnt = 0;

int main() {
   Myclass obj1,obj2,obj3;

   obj1.setdata(100);
   obj2.setdata(10);
   obj3.setdata(2000);

   cout << "Count of function is:" << Myclass :: showcount() ;

   return 0;
}
