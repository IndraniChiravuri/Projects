#include <stdio.h>
#include <stdlib.h>

int Fibonocci(int );

int main() {
    int num;
    printf("Enter the number:\t");
    scanf("%d", & num);
    printf("The %d number of fibonocci series is %d",num,Fibonocci(num));
    return 0;
}

int Fibonocci(int num) {
    if (num == 0) {
        return 0;
    }
    if (num == 1 || num == 2) {
        return 1;
    }
    return (Fibonocci(num - 1) + Fibonocci(num - 2));
}
