#include <iostream>

using namespace std;

class StudentDetails {
    private:
        int regdno;
        char name[20];
        char branch[10];
    public:
        void GetDetails() {

            cout << "Enter regdno " << endl;
            cin >> regdno;

            cout << "Enter name " << endl;
            cin >> name;

            cout << "Enter branch " << endl;
            cin >> branch;


        }
        void Display();

};

void StudentDetails :: Display() {

    cout << "Regdno is:" << regdno <<endl;
    cout << "Name is:" << name << endl;
    cout << "Branch is: " << branch << endl;

}


int main()
{
    StudentDetails s[20];
    int NOS;

    cout << "Enter number of students" << endl;
    cin >> NOS;
    for(int i = 0;i < NOS ; i++)
    {
        cout << "Enter the details of "<< i + 1 <<" student" << endl;
        s[i].GetDetails();
    }
    for(int i = 0;i < NOS ; i ++)
    {
        cout << "The details of "<< i + 1 << "student is " << endl;
        s[i].Display();
    }
    return 0;
}
