#include <iostream>

using namespace std;

template < class T >
T FindMin(T A[] , T Size) {
    T Min = A[0];
    for (int i = 1; i < Size; i++) {
        if (A[i] < Min) {
            Min = A[i];
        }
    }
    return Min;
}

int main() {
    int Nums[20],Size;
    cout << "Enter size:\t";
    cin >> Size;
    cout << "Enter elements:\n";
    for (int i = 0; i < Size; i++) {
        cin >> Nums[i];
    }
    cout << "Minimum number in the array is:\t" << FindMin(Nums,Size) << endl;

    return 0;
}
