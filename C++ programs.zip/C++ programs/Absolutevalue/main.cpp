#include <iostream>

using namespace std;

int main()
{
    int num;
    cout << "Enter the number:" << endl;
    cin >> num;

    if(num < 0)
        num = -num;
    cout << "The absolute value of given number is:" << num << endl;

    return 0;
}
