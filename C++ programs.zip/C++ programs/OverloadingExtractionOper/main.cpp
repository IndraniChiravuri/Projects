#include <iostream>
#include <iomanip>

using namespace std;

class FloatManip {
    private :
        int width;
        int precision;
        char Fill;
    public :
        FloatManip(int w, int p, int f) {
            width = w;
            precision = p;
            Fill = f;
        }
        friend ostream& operator << (ostream& os, FloatManip fm);
};

ostream& operator << (ostream& os, FloatManip fm) {
    os << setw(fm.width);
    os << setprecision(fm.precision);
    os << setfill(fm.Fill);
    os << setiosflags(ios :: showpos);
    os << setiosflags(ios::showpoint);

    return os;
}

FloatManip Setfloat(int w, int p, int f) {
    return (FloatManip(w,p,f));
}

int main() {
    float f1 = 189.5682, f2 = 21.289, f3 = 9634.1038, f4 = 106.002;

    cout << Setfloat(8,5,'*') << f1 << endl;
    cout << Setfloat(6,3,'@') << f2 << endl;
    cout << Setfloat(7,5,'$') << f3 << endl;
    cout << Setfloat(5,4,'!') << f4 << endl;

    return 0;
}
