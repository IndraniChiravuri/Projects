#include <iostream>

using namespace std;

int main()
{
    int num,rem,sum = 0;
    cout << "Enter the number:" << endl;
    cin >> num;
    do
    {
        rem = num % 10;
        sum += rem;
        num /= 10;
    }
    while(num > 0);

    cout << "The sum of digits of given number is" << sum << endl;

    return 0;
}
