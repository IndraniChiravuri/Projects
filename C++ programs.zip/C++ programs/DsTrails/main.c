#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    char * str1 = {"123456789"};
    for (i = 0;i <10; i++) {
        printf("%c",str1[i]);
    }
    return 0;
}
