#include <iostream>

using namespace std;

int main()
{
    int Salary;
    char Gender;

    cout << "Enter your gender:" << endl;
    cin >> Gender;
    cout << "Enter your present salary:" << endl;
    cin >> Salary;

    if(Gender == 'M')
    {
        if(Salary >= 10000)
            Salary += 500;
        else
            Salary += 300;
    }
    if(Gender == 'F')
    {
        if(Salary >= 20000)
            Salary += 1000;
        else
            Salary += 500;
    }

    cout << "Your salary after increment is "<< Salary << endl;
    return 0;
}
