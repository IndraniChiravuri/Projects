#include <iostream>

using namespace std;

int main()
{
    int i,n;
    int *p;

    cout << "How many numbers you want to type?" << endl;
    cin >> i;

    p = new int[i];
    if(p == NULL)
        cout << "Error:memory could not be allocated" << endl;
    else {
        for(n = 0;n < i; n ++)
        {
            cout << "Enter number:" << endl;
            cin >> p[n];
        }
        int sum = 0;
        for(n = 0; n < i ; n ++)
            sum += *p[n];
        cout << sum << endl;
        delete []p;
    }
    return 0;
}
