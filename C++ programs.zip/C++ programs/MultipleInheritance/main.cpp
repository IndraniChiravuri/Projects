#include <iostream>

using namespace std;

class Shape {
    public :
        int Length;
        int Breadth;
        void GetData() {
            cout << "Enter length:\t";
            cin >> Length;
            cout << "Enter breadth:\t";
            cin >> Breadth;
        }
        void Display() {
            cout << "\tLength is:\t" << Length << endl;
            cout << "\tBreadth is:\t" << Breadth << endl;
        }
};

class Colour {
    public :
        char clr[10];
        void SetColour() {
            cout << "Enter colour:\t";
            cin >> clr;
        }
        char* GetColour() {
            return clr;
        }
};

class ColouredRectangle : public Shape , public Colour {
    int area;
    public :
        void FindArea() {
            area = Length * Breadth;
        }
        void FillColour() {
            SetColour();
            cout << "You have selected the colour " << GetColour() << endl;
        }
        void DisplayArea() {
            cout << "Dimensions of rectangle are:" << endl;
            Display();
            cout << "\t Area is:\t" << area << endl;
        }
};

int main() {
    ColouredRectangle CR;
    CR.GetData();
    CR.FindArea();
    CR.FillColour();
    CR.DisplayArea();

    return 0;
}
