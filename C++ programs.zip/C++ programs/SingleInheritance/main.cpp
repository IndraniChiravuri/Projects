#include <iostream>

using namespace std;

class Shape {
    public :
        int Length;
        int Breadth;
        void GetData() {
            cout << "Enter length:\t";
            cin >> Length;
            cout << "Enter breadth:\t";
            cin >> Breadth;
        }
        void Display() {
            cout << "\tLength is:\t" << Length << endl;
            cout << "\tBreadth is:\t" << Breadth << endl;
        }
};

class Rectangle : public Shape {
    int area;
    public :
        void FindArea() {
            area = Length * Breadth;
        }
        void DisplayArea() {
            cout << "Dimensions of rectangle are:" << endl;
            Display();
            cout << "\t Area is:\t" << area << endl;
        }
};
int main() {
    Rectangle R;
    R.GetData();
    R.FindArea();
    R.DisplayArea();

    return 0;
}
