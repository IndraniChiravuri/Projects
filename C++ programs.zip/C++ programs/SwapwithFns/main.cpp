#include <iostream>

using namespace std;

int a,b,temp;
void Swapbyvalue(int ,int );

void Swapbyaddress(int * , int * );
void Swapbyreference(int &, int & );

int main()
{
    cout << "Enter the values of a and b:"<<endl;
    cin >> a >> b;

    Swapbyvalue(a,b);
    Swapbyaddress(&a,&b);
    Swapbyreference(a,b);

    return 0;
}

void Swapbyvalue(int a,int b) {
    temp = a;
    a = b;
    b = temp;
    cout <<"Values of a and b(call by value)" << a << " " << b << endl;
}

void Swapbyaddress(int *x,int *y) {
    temp = *x;
    *x = *y;
    *y = temp;
    cout <<"Values of a and b(call by address)" << *x << " "<< *y << endl;
}

void Swapbyreference(int &a,int &b) {
    temp = a;
    a = b;
    b = temp;
    cout <<"Values of a and b(call by reference)" << a << " "<< b << endl;
}
