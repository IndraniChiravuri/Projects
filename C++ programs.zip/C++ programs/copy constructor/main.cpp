#include <iostream>
using namespace std;
class code
{
int id;
public:
code(){};
code(int a)
{
id=a;
}
code(code &x)
{
id=x.id;
}
void display(void)
{
cout<<"the value of id is:"<<id<<endl;
}
};
int main()
{
code c (100);
code b(c);
code a=c;
cout<<"the value of a is:"<<endl;
b.display();
cout<<"the value of b is:"<<endl;
a.display();
return 0;
}


