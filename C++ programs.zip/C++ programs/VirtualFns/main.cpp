#include <iostream>

using namespace std;

class Shape {
    public :
        virtual void FindVolume() {
            Volume = 0;
        }
        void DisplayVolume() {
            cout << Volume << endl;
        }
    protected :
        double Volume;
};

class Cube : public Shape {
    private :
        double Side;
    public :
        void GetData() {
            cout << "Enter sidelength of cube:\t";
            cin >> Side;
        }
        void FindVolume() {
            Volume = Side * Side * Side;
        }
};

class Sphere : public Shape {
    private :
        double Radius;
    public :
        void GetData() {
            cout << "Enter radius of sphere:\t";
            cin >> Radius;
        }
        void FindVolume() {
            Volume = (4 * 3.14 * Radius * Radius * Radius) / 3;
        }
};

int main() {
    Cube c;
    c.GetData();
    c.FindVolume();
    cout << "Volume of the cube is:\t";
    c.DisplayVolume();

    Sphere s;
    s.GetData();
    s.FindVolume();
    cout << "Volume of the sphere is:\t";
    s.DisplayVolume();

    return 0;
}
