#include <iostream>

using namespace std;

int main()
{
    int marks;
    cout << "Enter your marks:" << endl;
    cin >> marks;

    if(marks > 35)
        cout << "Congrats!you qualified" << endl;
    else
        cout << "Sorry!you failed" << endl;

    return 0;
}
