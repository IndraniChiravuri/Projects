#include <iostream>

using namespace std;

class Vehicle {
    public :
        int ModelNo;
        int Price;
        void GetVehicle() {
            cout << "Enter modelno:\t";
            cin >> ModelNo;
            cout << "Enter price:\t";
            cin >> Price;
        }
        void DisplayVehicle() {
            cout << "\tModelno is:\t" << ModelNo << endl;
            cout << "\tPrice is:\t" << Price << endl;
        }
};

class LightWtVehicle : public Vehicle {
    public :
        int Mileage;
        char Fuel[10];
        void GetLightWt() {
            cout << "Enter mileage:\t";
            cin >> Mileage;
            cout << "Enter fuel:\t";
            cin >> Fuel;
        }
        void DisplayLightWt() {
            cout <<"\tMileage is:\t" << Mileage << endl;
            cout <<"\tFuel is:\t" << Fuel << endl;
        }
};

class HeavyWtVehicles : public Vehicle {
    public :
        int NumOfTyres;
        void GetHeavyWt() {
            cout << "Enter no. of tyres:\t";
            cin >> NumOfTyres;
        }
        void DisplayHeavyWt() {
            cout << "\tNo. of tyres are:\t" << NumOfTyres << endl;
        }
};

class Bike : public LightWtVehicle {
    int Gears;
    public :
        void GetBikeData() {
            GetVehicle();
            GetLightWt();
            cout << "Enter no. of gears:\t";
            cin >> Gears;
        }
        void DisplayBikeData() {
            cout << "Details of Bike are:" << endl;
            DisplayVehicle();
            DisplayLightWt();
            cout << "\tGears are:\t" << Gears << endl;
        }
};

class Car : public LightWtVehicle {
    private :
        int SeatingCapacity;
    public :
        void GetCarData() {
            GetVehicle();
            GetLightWt();
            cout << "Enter no.of seats:\t";
            cin >> SeatingCapacity;
        }
        void DisplayCarData() {
            cout << "Details of car are:\n";
            DisplayVehicle();
            DisplayLightWt();
            cout << "\tSeating capacity is:\t" << SeatingCapacity << endl;
        }
};

class Lorry : public HeavyWtVehicles {
    int LoadCapacity;
    public :
        void GetLorryData() {
            GetVehicle();
            GetHeavyWt();
            cout << "Enter load capacity:\t";
            cin >> LoadCapacity;
        }
        void DisplayLorryData() {
            cout << "Details of lorry are:\n";
            DisplayVehicle();
            DisplayHeavyWt();
            cout << "\tLoad capacity is:\t" << LoadCapacity << endl;
        }
};

class Bus : public HeavyWtVehicles {
    int NumOfSeats;
    public :
        void GetBusData() {
            GetVehicle();
            GetHeavyWt();
            cout << "Enter no. of seats:\t";
            cin >> NumOfSeats;
        }
        void DisplayBusData() {
            cout << "Details of bus are:\n";
            DisplayVehicle();
            DisplayHeavyWt();
            cout << "\tSeating capacity is:\t" << NumOfSeats << endl;
        }
};

int main() {
    Bike b;
    cout << "Enter the details of Bike:\n";
    b.GetBikeData();
    b.DisplayBikeData();

    Car c;
    cout << "Enter the details of Car:\n";
    c.GetCarData();
    c.DisplayCarData();

    Lorry l;
    cout << "Enter the details of Lorry:\n";
    l.GetLorryData();
    l.DisplayLorryData();

    Bus bu;
    cout << "Enter the details of Bus:\n";
    bu.GetBusData();
    bu.DisplayBusData();

    return 0;
}
