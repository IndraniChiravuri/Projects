#include <iostream>

using namespace std;

class Wife;
class Husband {
    int income;
    public :
        void InputIncome() {
            cout << "Enter income :" << endl;
            cin >> income;
        }

        void Display() {
            cout << "Income is: " << income << endl;
        }
    friend void Wife :: ChildSchoolFee(Husband h);
};

class Wife {
    int income;
    int m2;
    public :
        void InputIncome() {
            cout << "Enter income "<< endl;
            cin >> income;
        }
        void ChildSchoolFee(Husband h) {
            int fee;
            fee = h.income - 5000;
        }
        void SpendforKittyParty() {
            Husband h;
            int money;
            money = income - 5000;
            m2 = income - 500;
        }
        void Display() {
            cout << "Income is " << income << endl;
            cout << "Kitty party money is " << m2 << endl;
        }
};

int main() {

    Husband h;
    Wife w;

    h.InputIncome();
    h.Display();

    w.InputIncome();
    w.ChildSchoolFee(h);

    w.SpendforKittyParty();
    w.Display();

    return 0;
}

