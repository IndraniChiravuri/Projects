#include <iostream>

using namespace std;

template < class T >

class Stack {
    protected :
        T S[20];
        int top;
    public:
        Stack() {
            top = -1;
        }
        void Push(T item) {
            if (top == 20) {
                cout << "Overflow\n";
            } else {
                S[++top] = item;
                cout << "Pushed\n";
            }
        }

        T Pop() {
            if (top == -1) {
                cout << "Underflow\n";
            } else {
                cout << "Poped\n";
                return (S[top--]);

            }
        }

        void Display() {
            if (top == -1) {
                cout << "Underflow\n";
            } else {
                for (int i = top; i != -1; i--) {
                    cout << S[i] << "\t";
                }
                cout << endl;
            }
        }
};


int main() {
    Stack <int> Istack;
    Istack.Push(10);
    Istack.Push(9);
    Istack.Pop();
    Istack.Push(2);
    Istack.Display();

    Stack <float> Fstack;
    Fstack.Push(21.2f);
    Fstack.Push(9.7f);
    Fstack.Push(39.8f);
    Fstack.Pop();
    Fstack.Pop();
    Fstack.Display();

    return 0;
}
