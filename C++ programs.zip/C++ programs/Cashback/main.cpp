#include <iostream>

using namespace std;

int main()
{
    int amount , cashback = 0 ;

    cout << "Enter the amount:" << endl;
    cin >> amount ;
    if (amount >= 1000)
        cashback = 100 ;
    cout << "Your cashback amount is:" << cashback << endl ;
    return 0;
}
