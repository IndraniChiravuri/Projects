#include <iostream>
#include <iomanip>

using namespace std;

ostream& printdollar(ostream& os) {
    os << "$";
    return os;
}

ostream& order(ostream& os) {
    os << setiosflags(ios :: showpos);
    os << setiosflags(ios :: showpoint);
    os << setiosflags(ios :: fixed);
    os << setfill('*');
    os << setprecision(2);
    os << setw(10);
    return os;
}
int main() {
    float f1;
    cout << "Enter a value:\t";
    cin >> f1;
    cout << "The money you entered is:\t" << printdollar << order << f1 << endl;
    return 0;
}
