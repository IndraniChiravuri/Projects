#include <iostream>

using namespace std;

int main()
{
    int sum = 0,rem,num;
    cout << "Enter number" << endl;
    cin >> num;
    for(num ; num > 0 ;num /= 10)
    {
        rem = num % 10;
        sum += rem;
    }
    cout << "The sum of digits of given number is " << sum << endl;

    return 0;
}
