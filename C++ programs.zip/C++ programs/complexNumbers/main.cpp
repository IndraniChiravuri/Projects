#include <iostream>

using namespace std;

class Complexnumber {
    int real,imag;
    public:
        void Getdata() {

            cout << "Enter the real part :" << endl;
            cin >> real;

            cout << "Enter Imaginary part :" << endl;
            cin >> imag;
        }
        void Display() {
            cout << real << " + " << imag << "i" << endl;
        }

        Complexnumber Addition(Complexnumber num2)
        {
            Complexnumber num3;

            num3.real = real + num2.real;
            num3.imag = imag + num2.imag;
            return num3;
        }

        Complexnumber Subtration(Complexnumber num2) {

            Complexnumber num3;

            num3.real = real - num2.real;
            num3.imag = imag - num2.imag;

            return num3;
        }

        Complexnumber Multiplication(Complexnumber num2) {
            Complexnumber num3;

            num3.real = (real * num2.real) - (imag * num2.imag);
            num3.imag = (real * num2.imag) + (imag * num2. real);

            return num3;
        }

        Complexnumber Division(Complexnumber num2) {

            Complexnumber num3;

            num3.real = ((real * num2.real) + (imag * num2.imag)) / ((num2.real * num2.real) + (num2.imag * num2.imag));
            num3.imag = ((imag * num2.real) - (real * num2.imag)) / ((num2.real * num2.real) + (num2.imag * num2.imag));

            return num3;
        }
    };
int main()
{
    int choice;
    Complexnumber num1,num2,num3;

    cout << "1.Addition 2.Subtraction 3.Multiplication 4.Division " << endl;
    cout << "Enter the choice:" << endl;
    cin >> choice;
    if(choice < 5) {
        cout <<  "First complex number" << endl;
        num1.Getdata();

        cout << "Second complex number" << endl;
        num2.Getdata();
    }

    switch(choice) {

        case 1 :
           num3 = num1.Addition(num2);
           cout << "Addition of 2 numbers is:" << endl;
           num3.Display();
           break;
        case 2:
            num3 = num1.Subtration(num2);
            cout << "Subtraction of 2 numbers is:" << endl;
            num3.Display();
            break;
        case 3:
            num3 = num1.Multiplication(num2);
            cout << "Multiplication of 2 numbers is:" << endl;
            num3.Display();
            break;
        case 4:
            num3 = num1.Division(num2);
            cout << "Division of a numbers is:" << endl;
            num3.Display();
            break;
        default:
            cout << "Enter your choice b/w 1 and 4" << endl;
            break;
    }
}

