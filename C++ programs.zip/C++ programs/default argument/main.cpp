#include <iostream>
#include<math.h>

using namespace std;
double power(double n,int p=2)
{return pow(n,p);}
int main()
{
 cout<<power(5,3);
 cout<<power(6,4);
 cout<<power(8);
 return 0;
 }
