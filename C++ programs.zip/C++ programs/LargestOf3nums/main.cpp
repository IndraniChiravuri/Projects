#include <iostream>

using namespace std;

int Largest(int , int , int );

int main()
{
    int a,b,c;

    cout << "Enter the 3 numbers:" << endl;
    cin >> a >> b >> c;

    cout << "The largest of given numbers is " << Largest(a,b,c);

    return 0;
}

 inline int Largest(int a,int b,int c)
{
    return(a > b ? (a > c ? a : c) : (b > c ? b : c));

}
