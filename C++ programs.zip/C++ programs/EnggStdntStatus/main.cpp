#include <iostream>

using namespace std;

int main()
{
    int internal,external,total;
    cout << "Enter your internal and external marks:" << endl;
    cin >> internal >> external;

    total = internal + external ;
    if(external >= 21 && total >= 40)
        cout << "Congrats!You passed" << endl;
    else
        cout << "Sorry!You failed" << endl;

    return 0;
}
