#include <iostream>

using namespace std;

class BackUp {
    public :
        virtual void Dump() = 0;
};

class SampleClass1 : public BackUp {
    int num1,num2,num3;
    public :
        SampleClass1(int n1,int n2,int n3) {
            num1 = n1;num2 = n2;num3 = n3;
        }
        void Dump() {
            cout << "Values are:\t";
            cout << num1 <<  "\t" << num2 << "\t" << num3 << endl;
        }
};

class SampleClass2 : public BackUp {
    int num1,num2,num3;
    public :
        SampleClass2(int n1,int n2,int n3) {
            num1 = n1;num2 = n2;num3 = n3;
        }
        void Dump() {
            cout << "Values are:\t";
            cout << num1 <<  "\t" << num2 << "\t" << num3 << endl;
        }
};
int main()
{
    BackUp *Bptr[5];
    SampleClass1 sc1(10,9,8);
    SampleClass2 sc2(60,70,80);
    Bptr[0] = &sc1;
    Bptr[1] = &sc2;

    for (int i = 0; i < 2; i++) {
        Bptr[i] -> Dump();
    }

    return 0;
}
