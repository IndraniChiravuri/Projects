#include <iostream>

using namespace std;

int main()
{
    int num1,num2;
    cout << "Enter two numbers:" << endl;
    cin >> num1 >> num2;

    switch(num1 > num2)
    {
        case 1:
                cout << num1 << " is greaterthan " << num2 << endl;
                break;
        case 0:
                cout << num2 << " is greaterthan " << num1 << endl;
    }

    return 0;
}
