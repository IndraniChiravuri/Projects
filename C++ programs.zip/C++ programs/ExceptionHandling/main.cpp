#include <iostream>

using namespace std;

class DIVIDE_ERR { };

int main()
{
    int num1,num2;
    cout << "Enter num1,num2:\t";
    cin >> num1 >> num2;
    try {
        if (num2 == 0)
            throw DIVIDE_ERR();
        cout << "Division is:\t" << num1 / num2;
    }
    catch(DIVIDE_ERR& dv) {
        cout << "Division error(num2 > 0)";
    }
    return 0;
}
