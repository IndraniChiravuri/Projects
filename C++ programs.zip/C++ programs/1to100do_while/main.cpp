#include <iostream>

using namespace std;

int main()
{
    int i = 1;
    cout << "Natural numbers:" << endl;

    do
    {
        cout << i << " ";
        i += 1;
    }
    while(i < 101);

    return 0;
}
