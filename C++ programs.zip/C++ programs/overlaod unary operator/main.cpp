#include <iostream>
using namespace std;
class space
{
int x;
int y;
int z;
public:
void getData(int a,int b,int c);
void display(void)
{
cout<<"x="<<x<<"y="<<y<<"z="<<endl;
}
void operator -();
};
void space ::getData(int a,int b,int c)
{
x=a;
y=z;
z=c;
}
void space::operator-()
{
x= -x;
y= -y;
z= -z;
}
int main()
{
space s1;
s1.getData(2,-3,5);
cout<<"before calling operator function"<<endl;
s1.display();
-s1;
cout<<"after calling operator function"<<endl;
s1.display();
}
