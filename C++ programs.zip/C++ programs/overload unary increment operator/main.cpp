#include<iostream>
using namespace std;
class Time
{
int hours;
int minutes;
public:
Time()//default constructor invoked when object declared
{
minutes=0;
hours=0;
}
Time(int h,int m)
{
hours=h;
minutes=m;
}
void displayTime()
{
cout<<"the Time is H:"<<hours<<endl;
cout<<"the Time is M:"<<minutes<<endl;
}
Time operator++()//overloading prefix operator
{
++minutes;
if (minutes >=60)
{
++hours;
minutes-=60;
}
return Time (hours,minutes);
}
Time operator++(int)//overloading prefix operator
{
minutes++;
if (minutes>=60)
{
hours++;
minutes -=60;
}
return Time(hours,minutes);
}
};
int main()
{
Time T1(11,59),T2(10,45);
cout<<"before calling overload increment operator"<<endl;
T1.displayTime();
T2.displayTime();
++T1;
cout<<"after calling overload increment operator"<<endl;
T2.displayTime();
T2++;
return 0;
}


