#include <iostream>
#include <string.h>

using namespace std;

class Person {
    char firstname[20];
    public :
        Person() {
            firstname[0] = '\0';
        }

        Person(char *fname) {
            strcpy(firstname,fname);
        }

        Person(Person &p) {
            strcpy(this -> firstname,p.firstname);
        }

        void Displayname() {
            cout << "Name is " << firstname << endl;
        }
};


int main()
{
    Person p1("Gwincy");
    Person p2 = p1;

    p1.Displayname();
    p2.Displayname();

    return 0;
}
