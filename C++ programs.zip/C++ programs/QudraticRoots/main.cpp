#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

ostream& format(ostream& os) {
    os.setf(ios :: showpos);
    os.setf(ios :: internal, ios :: adjustfield);
    os.width(10);
    return os;
}

int main() {

    float a,b,c;
    cout << "Enter 3 coefficients:\t";
    cin >> a >> b >> c;
    float d = (b * b) - (4 * a * c);

    if (d > 0) {
        cout << "Roots are real & distinct\t";
       /* float r1 = (-b + sqrt(d)) / (2 * a);
        float r2 = (-b - sqrt(d)) / (2 * a);*/
        cout << format << (-b + sqrt(d)) / (2 * a) << "\t";
        cout << format << (-b - sqrt(d)) / (2 * a)<< endl;
    }
    if (d < 0) {
        cout << "Roots are complex and they are\t";
        cout << format << -b / (2 * a) << "\t";
        cout << format << d / (2 * a) << endl;
    }
    if(d == 0) {
        cout << "Roots are equal and they are\t";
        cout << format << (-b / (2 * a)) << endl;
    }

    return 0;
}
