#include <iostream>

using namespace std;

class Shape {
    public :
        void Paint() {
            cout << "A shape is painting\n";
        }
};

class Rectangle : public Shape {
    public :
        void Paint() {
            cout << "Rectangle is painting\n";
        }
};

class square : public Shape {
    public :
        void Paint() {
            cout << "A square is painting\n";
        }
};

class Circle : public Shape {
    public :
        void Paint() {
            cout << "Circle is painting\n";
        }
};

int main()
{
    Shape s;
    s . Paint();
    Rectangle r;
    r . Paint();
    square sq;
    sq . Paint();
    Circle c;
    c . Paint();

    return 0;
}
