#include <iostream>
#include<math.h>

using namespace std;

double Power(double n,int p = 2 );

int main()
{
    int p;
    double n;

    cout << Power(7) << endl;

    cout << Power(9,3) << endl;

    return 0;
}

inline double Power(double n,int p)
{
    return (pow(n,p));
}
