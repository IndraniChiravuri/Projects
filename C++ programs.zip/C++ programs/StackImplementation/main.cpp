#include <iostream>
#define Max 20

using namespace std;

class Stack {
    int top;
    int s[Max];
    public:
        Stack() {
            top = -1;
            for (int i = 0; i < Max; i++ )
                s[i] = 0;
        }

        void Push(int ele) {
            if(top == Max -1)
                cout << "Stack is full" << endl;
            else
                s[ ++ top] = ele;
        }

        int Pop() {
            if (top == -1)
                cout << "Stack is empty" << endl;
            else
                return(s[top --]);
        }

        void Display() {
            if (top == -1)
                cout << "Stack is empty" << endl;
            else {
                cout <<"Elements in the stack are" << endl;
                for (int i = top; i >= 0; i --)
                    cout << s[i] << '\t';
            }
        }
};


int main()
{
    Stack s1;
    int choice,ele;
    cout << "Main menu is" << endl;
    cout << "1.Push 2.Pop 3.Display 4.Exit" << endl;

    do {
        cout << "Enter your choice" << endl;
        cin >> choice;

        switch (choice) {

            case 1:
                cout << "Enter the element" << endl;
                cin >> ele;
                s1.Push(ele);
                break;
            case 2:
                cout << "The popped element is  " << s1.Pop() << endl;
                cout << "After popping" << endl;
                s1.Display();
                cout << endl;
                break;
            case 3:
                s1.Display();
                cout << endl;
                break;
            case 4:
                cout << "End of execution" << endl;
                break;
            default :
                cout << "Please enter your choice b/w 1 and 4" << endl;
                break;

        }
    }while (choice != 4);

    return 0;
}
