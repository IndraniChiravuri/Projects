#include <iostream>

using namespace std;

class Index {
    int i;
    public:
        Index(){
            i = 0;
        }
        Index(int x){
            i = x;
        }
        Index operator ++(){
            i += 1;
            return *this;
        }
        Index operator ++ (int ) {
            Index temp;
            temp. i = i;
            i += 1;
            return temp;
        }
        void Display() {
            cout << i << endl;
        }
};

int main()
{
    Index a = 21;
    Index b,c;
    b = a ++;
    c = ++ a;
    a.Display();
    b.Display();
    c.Display();

    return 0;
}
