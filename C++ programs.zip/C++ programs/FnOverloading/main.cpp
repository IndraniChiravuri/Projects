#include <iostream>

using namespace std;

void Swap(int ,int );
void Swap(float ,float );
void Swap(char ,char );

int main()
{
    int num1,num2;
    cout << "Enter two integers:\t";
    cin >> num1 >> num2;
    cout << "Values of num1 and num2 before swapping are:\t" << num1 << "\t" << num2 << endl;
    Swap(num1,num2);

    char ch1,ch2;
    cout << "Enter 2 characters:\t";
    cin >> ch1 >> ch2;
    cout << "Values of ch1 and ch2 before swapping are:\t" << ch1 << "\t" << ch2 << endl;
    Swap(ch1,ch2);

    float f1,f2;
    cout << "Enter 2 float values:\t";
    cin >> f1 >> f2;
    cout << "Values of f1 and f2 before swapping are:\t" << f1 << "\t" << f2 << endl;
    Swap(f1,f2);

    return 0;
}

void Swap(int num1, int num2) {
    int temp = num1;
    num1 = num2;
    num2 = temp;
    cout << "Values of num1 and num2 after swapping are:\t"<< num1 << "\t" << num2 << endl;
}

void Swap(float f1,float f2) {
    float temp = f1;
    f1 = f2;
    f2 = temp;
    cout << "Values of f1 and f2 after swapping are:\t" << f1 << "\t" << f2 << endl;
}

void Swap(char ch1, char ch2) {
    char temp = ch1;
    ch1 = ch2;
    ch2 = temp;
    cout << "Values of ch1 and ch2 after swapping are:\t" << ch1 << "\t" << ch2 << endl;
}
